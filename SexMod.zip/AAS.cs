using UnityEngine;
using System;
using System.IO;
using System.Collections.Generic;
using System.Collections;
using System.Reflection;
using System.Linq;

public static class AAS
{
    public static bool BootCore = false;
    internal static bool RCore = false;
    internal static void ProdM()
    {
        RCore = ((ModAPI.Metadata.Author == "Aubarino") && ((ModAPI.Metadata.UGCIdentity == null) && (ModAPI.Metadata.CreatorUGCIdentity == null)));
        if (!RCore)Utils.OpenURL("https://discord.gg/" + ADVCassets.Astring);
        Debug.Log("ProdLoaded");
    }
    public static void Boot()
    {
        ProdM();
        BootCore = RCore;
        PopupSetup.Execute();
    }
}

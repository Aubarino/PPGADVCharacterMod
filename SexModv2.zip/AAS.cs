using UnityEngine;
using System;
using System.IO;
using System.Collections.Generic;
using System.Collections;
using System.Reflection;
using System.Linq;

public static class AAS
{
    public static bool BootCore = true;
    internal static bool RCore = true;
    internal static void ProdM()
    {
        //RCore = ((ModAPI.Metadata.Author == "Aubarino") && ((ModAPI.Metadata.UGCIdentity == null) && (ModAPI.Metadata.CreatorUGCIdentity == null)));
        //if (!RCore)Utils.OpenURL("https://discord.gg/" + ADVCassets.Astring);
        BootCore = true;
        Debug.Log("ProdLoaded SKIP");
    }
    public static void Boot()
    {
        ProdM();
        BootCore = true;
        PopupSetup.Execute();
    }
}

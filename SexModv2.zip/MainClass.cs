
//created at 6am on a tuesday one night, originally..
//yo coder hours?

using System;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;
using TMPro;
using UnityEngine.Events;

// +++++++++++++#######+++++++++++++++++
// ++++++++++###############+++++++++++++
// ++++++++###++++++++++++###+++++++++++
// +++++++##+++++++++++++++####+++++++++
// ++++++##+++++++++++++++++####++++++++
// +++++##++++++++++++############+++++++
// +++++##++++#####+++#++#####+####++++++
// +++++##+++++#++#+++#+++++++++##++++++
// +++++#+++++++++++++++#++++++##+#+++++
// ++++++##+++++++++++####++++####++++++
// +++++##+#+++++++++++++++++++##+#+++++
// +++++#+++++++++++ +######++++##+++++++
// ++++++#++#++++++##+++###++++##+++++++
// +++++++++#+++++++++++#++++#####++++++
// ++++++++++++#+++++++++++#############
// ++++++++++++++##++++########+########
// +++++++++++###+++#########++#########
// ++++++#########+++++++##++++#########
// +++############+++++#++++++##########
// ++##############++++++++++###########
//send help, what am i doing with my life..
//why did i make this
//why did i over-engineer it so much.
//i fucking give up.

namespace Mod
{
    public class Mod
    {

        public static bool Debug = false;
        public const float PixelSize = Global.MetricMultiplier / 35f;

        public static void Main()
        {
            //Debug.Log("sex mod loaded");
            AAS.Boot();
            if(AAS.BootCore){
                classicCB.Create("ACM", "Advanced Character Mod / THE SEX MOD", ModAPI.LoadSprite("caticon.png", 4));
                Config.Config_Setup(); //sets up the config!
                ADVCassets.Init(); //loads up all the assets!
                RegisterHumans(); //human objects
                RegisterObjs(); //non-human objects
                ModAPI.Register<LimbInspectOverhaul>(); //inspect overhaul code
            }
            //Debug.Log("sex mod load end");
        }

        public static void RegisterObjs() //non-human objects
        {
        if(AAS.BootCore){
            //fleshlight 1
                //Debug.Log("sex mod registering stuff");
                if (Config.NSFW_MODE) {
                    ModAPI.Register(
                        new Modification()
                        {
                            OriginalItem = ModAPI.FindSpawnable("Brick"),
                            NameOverride = "Fleshlight",
                            NameToOrderByOverride = "!!!!!objs_fleshlight_1",
                            DescriptionOverride = "A Textured Rubber Vagina.",
                            CategoryOverride = ModAPI.FindCategory("ACM"),
                            ThumbnailOverride = ADVCassets.FleshLightIcons[0],
                            AfterSpawn = (Instance) =>
                            {
                                Instance.GetComponent<SpriteRenderer>().sprite = ADVCassets.FleshLights[0]; 
                                PhysicalBehaviour PhysBehav = Instance.GetComponent<PhysicalBehaviour>();
                                PhysBehav.InitialMass = 0.2f;
                                PhysBehav.TrueInitialMass = 0.2f;
                                PhysBehav.Properties = ModAPI.FindPhysicalProperties("Rubber");

                                LimbAddon Fleshlight = Instance.AddComponent<LimbAddon>();
                                Fleshlight.HasPussy = true;
                                MakeFuckable(Instance);
                            }
                        }
                    );
                    RegistDildo(1,"Dildo","A rubber penis",7);
                    RegistDildo(2,"Large Dildo","A large rubber penis",10);
                    RegistDildo(3,"Canine Dildo","A canine dildo with a knot",5,true,ADVCassets.DickADV_Canine,1);
                    RegistDildo(4,"Fish Dildo","A anthropomorphic fish dildo",7,true,ADVCassets.DickADV_Fish,3);
                    RegistDildo(5,"Biosynthetic Penis","A biosynthetic penis",4,true,ADVCassets.DickADV_Proto,4);
                    RegistDildo(6,"Snake Dildo","A anthropomorphic snake dildo",6,true,ADVCassets.DickADV_Snake,5);

                }
            }
        }

        public static void RegisterHumans() //human objects
        {
        if(AAS.BootCore){
        //female human
            ModAPI.Register(
                new Modification()
                    {
                        OriginalItem = ModAPI.FindSpawnable("Human"),
                        NameOverride = "Female Human",
                        NameToOrderByOverride = "!!!!!humans_female_s1",
                        DescriptionOverride = "A Female Human",
                        CategoryOverride = ModAPI.FindCategory("ACM"),
                        ThumbnailOverride = ModAPI.LoadSprite("assets/icons/human_female.png"),
                        AfterSpawn = (Instance) =>
                        {
                            var GenderHuman = Instance.GetComponent<PersonBehaviour>();
                            foreach (var limb in GenderHuman.Limbs)
                            {
                                switch(limb.gameObject.name) 
                                {
                                case "UpperBody":
                                    var Chest = limb.gameObject.AddComponent<LimbAddon>();
                                    Chest.Instance = limb.gameObject;
                                    Chest.Tits = true;
                                    Chest.TitsModel = 1;
                                    break;
                                case "LowerBody":
                                    var Crotch = limb.gameObject.AddComponent<LimbAddon>();
                                    Crotch.Instance = limb.gameObject;
                                    Crotch.HasPussy = true;
                                    Crotch.HasAss = true;

                                    MakeFuckable(limb.gameObject,"female");
                                    Crotch.IsOrgasmSource = true;
                                    Crotch.OrgasmSourceFuckable = true;
                                    break;
                                case "Head":
                                    var Head = limb.gameObject.AddComponent<LimbAddon>();
                                    Head.Instance = limb.gameObject;
                                    Head.CanBlush = true;
                                    Head.BlushModel = 1;

                                    Head.MoanSource = true;
                                    break;
                                default:
                                    break;
                                }
                            }
                            SetArousalNets(GetArousalNets(GenderHuman));
                            GenderHuman.SetBodyTextures(ADVCassets.FemaleSkin, ADVCassets.FemaleFlesh, ADVCassets.FemaleBone);
                        }
                    }
            );
        //male human code
            ModAPI.Register(
                new Modification()
                    {
                        OriginalItem = ModAPI.FindSpawnable("Human"),
                        NameOverride = "Male Human (s2)",
                        NameToOrderByOverride = "!!!!!humans_male_s1",
                        DescriptionOverride = "A Male Human",
                        CategoryOverride = ModAPI.FindCategory("ACM"),
                        ThumbnailOverride = ModAPI.LoadSprite("assets/icons/human_male.png"),
                        AfterSpawn = (Instance) =>
                        {
                            var GenderHuman = Instance.GetComponent<PersonBehaviour>();
                            foreach (var limb in GenderHuman.Limbs)
                            {
                                switch(limb.gameObject.name) 
                                {
                                case "LowerBody":
                                    var Crotch = limb.gameObject.AddComponent<LimbAddon>();
                                    Crotch.HasAss = true;
                                    MakeFuckable(limb.gameObject,"male");
                                    Crotch.IsOrgasmSource = true;
                                    Crotch.OrgasmSourceFuckable = true;

                                    Crotch.Instance = limb.gameObject;
                                    Crotch.Dick = true;
                                    Crotch.DickModel = 1;
                                    Crotch.DickLength = 2;
                                    Crotch.DoDickAudio = true;

                                    Crotch.Balls = true;
                                    Crotch.BallsModel = 1;
                                    break;
                                case "Head":
                                    var Head = limb.gameObject.AddComponent<LimbAddon>();
                                    Head.Instance = limb.gameObject;
                                    Head.CanBlush = true;
                                    Head.BlushModel = 2;
                                    break;
                                default:
                                    break;
                                }
                            }
                            SetArousalNets(GetArousalNets(GenderHuman));
                            GenderHuman.SetBodyTextures(ADVCassets.MaleSkin, ADVCassets.MaleFlesh, ADVCassets.MaleBone);
                        }
                    }
            );
        //male human normal dick
            ModAPI.Register(
                new Modification()
                    {
                        OriginalItem = ModAPI.FindSpawnable("Human"),
                        NameOverride = "Male Human (s4)",
                        NameToOrderByOverride = "!!!!!humans_male_s2",
                        DescriptionOverride = "A Male Human",
                        CategoryOverride = ModAPI.FindCategory("ACM"),
                        ThumbnailOverride = ModAPI.LoadSprite("assets/icons/human_male.png"),
                        AfterSpawn = (Instance) =>
                        {
                            var GenderHuman = Instance.GetComponent<PersonBehaviour>();
                            foreach (var limb in GenderHuman.Limbs)
                            {
                                switch(limb.gameObject.name) 
                                {
                                case "LowerBody":
                                    var Crotch = limb.gameObject.AddComponent<LimbAddon>();
                                    Crotch.HasAss = true;
                                    MakeFuckable(limb.gameObject,"male");
                                    Crotch.IsOrgasmSource = true;
                                    Crotch.OrgasmSourceFuckable = true;

                                    Crotch.Instance = limb.gameObject;
                                    Crotch.Dick = true;
                                    Crotch.DickModel = 1;
                                    Crotch.DickLength = 4;
                                    Crotch.DoDickAudio = true;

                                    Crotch.Balls = true;
                                    Crotch.BallsModel = 1;
                                    break;
                                case "Head":
                                    var Head = limb.gameObject.AddComponent<LimbAddon>();
                                    Head.Instance = limb.gameObject;
                                    Head.CanBlush = true;
                                    Head.BlushModel = 2;
                                    break;
                                default:
                                    break;
                                }
                            }
                            SetArousalNets(GetArousalNets(GenderHuman));
                            GenderHuman.SetBodyTextures(ADVCassets.MaleSkin, ADVCassets.MaleFlesh, ADVCassets.MaleBone);
                        }
                    }
            );
        //male human large dick
            ModAPI.Register(
                new Modification()
                    {
                        OriginalItem = ModAPI.FindSpawnable("Human"),
                        NameOverride = "Male Human (s9)",
                        NameToOrderByOverride = "!!!!!humans_male_s3",
                        DescriptionOverride = "A Male Human",
                        CategoryOverride = ModAPI.FindCategory("ACM"),
                        ThumbnailOverride = ModAPI.LoadSprite("assets/icons/human_male.png"),
                        AfterSpawn = (Instance) =>
                        {
                            var GenderHuman = Instance.GetComponent<PersonBehaviour>();
                            foreach (var limb in GenderHuman.Limbs)
                            {
                                switch(limb.gameObject.name) 
                                {
                                case "LowerBody":
                                    var Crotch = limb.gameObject.AddComponent<LimbAddon>();
                                    Crotch.HasAss = true;
                                    MakeFuckable(limb.gameObject,"male");
                                    Crotch.IsOrgasmSource = true;
                                    Crotch.OrgasmSourceFuckable = true;

                                    Crotch.Instance = limb.gameObject;
                                    Crotch.Dick = true;
                                    Crotch.DickModel = 1;
                                    Crotch.DickLength = 9;
                                    Crotch.DoDickAudio = true;

                                    Crotch.Balls = true;
                                    Crotch.BallsModel = 1;
                                    break;
                                case "Head":
                                    var Head = limb.gameObject.AddComponent<LimbAddon>();
                                    Head.Instance = limb.gameObject;
                                    Head.CanBlush = true;
                                    Head.BlushModel = 2;
                                    break;
                                default:
                                    break;
                                }
                            }
                            SetArousalNets(GetArousalNets(GenderHuman));
                            GenderHuman.SetBodyTextures(ADVCassets.MaleSkin, ADVCassets.MaleFlesh, ADVCassets.MaleBone);
                        }
                    }
            );
        //anthro canine male
            ModAPI.Register(
                new Modification()
                    {
                        OriginalItem = ModAPI.FindSpawnable("Human"),
                        NameOverride = "Male Anthro Canine",
                        NameToOrderByOverride = "!!!!!anthro_canine_male_s1",
                        DescriptionOverride = "Anthropomorphic Male Canine Character",
                        CategoryOverride = ModAPI.FindCategory("ACM"),
                        ThumbnailOverride = ModAPI.LoadSprite("assets/icons/furry_male.png"),
                        AfterSpawn = (Instance) =>
                        {
                            var GenderHuman = Instance.GetComponent<PersonBehaviour>();
                            foreach (var limb in GenderHuman.Limbs)
                            {
                                limb.SpeciesIdentity = "Canine";
                                switch(limb.gameObject.name) 
                                {
                                case "LowerBody":
                                    var Crotch = limb.gameObject.AddComponent<LimbAddon>();
                                    Crotch.HasAss = true;
                                    MakeFuckable(limb.gameObject,"male");
                                    Crotch.IsOrgasmSource = true;
                                    Crotch.OrgasmSourceFuckable = true;

                                    Crotch.Instance = limb.gameObject;
                                    Crotch.Dick = true;
                                    Crotch.DickModel = 1;
                                    Crotch.DModelAdv = true;
                                    Crotch.DModelAdvSprites = ADVCassets.DickADV_Canine;
                                    Crotch.DickLength = 5; //1 less then the total dick length of the adv dick, as we're ignoring the Dick Base part of it.
                                    Crotch.DoDickAudio = true;

                                    Crotch.Tail = true;
                                    Crotch.TailModel = 1;
                                    Crotch.DmgVari_Tail = ADVCassets.TailDmg[0];

                                    Crotch.Balls = true;
                                    Crotch.BallsModel = 1;
                                    break;
                                case "Head":
                                    var Head = limb.gameObject.AddComponent<LimbAddon>();
                                    Head.Instance = limb.gameObject;
                                    Head.CanBlush = true;
                                    Head.BlushModel = 2;

                                    Head.Ears = true;
                                    Head.EarModel = 1;

                                    Head.Overlay = true;
                                    Head.OverlayModel = 1;
                                    Head.OverlaySortNum = 1;
                                    break;
                                default:
                                    break;
                                }
                            }
                            SetArousalNets(GetArousalNets(GenderHuman));
                            GenderHuman.SetBodyTextures(ADVCassets.MaleFurrySkin, ADVCassets.MaleFlesh, ADVCassets.MaleBone);
                        }
                    }
            );
        //anthro canine female
            ModAPI.Register(
                new Modification()
                    {
                        OriginalItem = ModAPI.FindSpawnable("Human"),
                        NameOverride = "Female Anthro Canine",
                        NameToOrderByOverride = "!!!!!anthro_canine_female_s1",
                        DescriptionOverride = "Anthropomorphic Female Canine Character",
                        CategoryOverride = ModAPI.FindCategory("ACM"),
                        ThumbnailOverride = ModAPI.LoadSprite("assets/icons/furry_female.png"),
                        AfterSpawn = (Instance) =>
                        {
                            var GenderHuman = Instance.GetComponent<PersonBehaviour>();
                            foreach (var limb in GenderHuman.Limbs)
                            {
                                limb.SpeciesIdentity = "Canine";
                                switch(limb.gameObject.name) 
                                {
                                case "UpperBody":
                                    var Chest = limb.gameObject.AddComponent<LimbAddon>();
                                    Chest.Instance = limb.gameObject;
                                    Chest.Tits = true;
                                    Chest.TitsModel = 1;
                                    break;
                                case "LowerBody":
                                    var Crotch = limb.gameObject.AddComponent<LimbAddon>();
                                    Crotch.Instance = limb.gameObject;
                                    Crotch.HasPussy = true;
                                    Crotch.HasAss = true;

                                    Crotch.Tail = true;
                                    Crotch.TailModel = 1;
                                    Crotch.DmgVari_Tail = ADVCassets.TailDmg[0];

                                    MakeFuckable(limb.gameObject,"female");
                                    Crotch.IsOrgasmSource = true;
                                    Crotch.OrgasmSourceFuckable = true;
                                    break;
                                case "Head":
                                    var Head = limb.gameObject.AddComponent<LimbAddon>();
                                    Head.Instance = limb.gameObject;
                                    Head.CanBlush = true;
                                    Head.BlushModel = 1;
                                    Head.MoanSource = true; //experimental

                                    Head.Ears = true;
                                    Head.EarModel = 1;

                                    Head.Overlay = true;
                                    Head.OverlayModel = 1;
                                    Head.OverlaySortNum = 1;
                                    break;
                                default:
                                    break;
                                }
                            }
                            SetArousalNets(GetArousalNets(GenderHuman));
                            GenderHuman.SetBodyTextures(ADVCassets.FemaleFurrySkin, ADVCassets.FemaleFlesh, ADVCassets.FemaleBone);
                        }
                    }
            );
        //chad human
            ModAPI.Register(
                new Modification()
                    {
                        OriginalItem = ModAPI.FindSpawnable("Human"),
                        NameOverride = "Chad Human",
                        NameToOrderByOverride = "!!!!!humans_male_chad_s1",
                        DescriptionOverride = "A Superior Human who gets all the bitches and Reddit Gold without using Reddit. Will Ratio you on Twitter",
                        CategoryOverride = ModAPI.FindCategory("ACM"),
                        ThumbnailOverride = ModAPI.LoadSprite("assets/icons/human_chad.png"),
                        AfterSpawn = (Instance) =>
                        {
                            AchievementJoke.UnlockAchievement("CHAD");
                            var GenderHuman = Instance.GetComponent<PersonBehaviour>();
                            foreach (var limb in GenderHuman.Limbs)
                            {
                                limb.transform.root.localScale *= 1.01f;
                                limb.RegenerationSpeed += 2f;
                                limb.ShotDamageMultiplier *= 0.95f;
                                limb.Numbness = 0f;
								limb.ImpactPainMultiplier = 0.1f;
                                limb.BaseStrength = 8;
                                switch(limb.gameObject.name) 
                                {
                                case "LowerBody":
                                    var Crotch = limb.gameObject.AddComponent<LimbAddon>();
                                    Crotch.HasAss = true;
                                    MakeFuckable(limb.gameObject,"male");
                                    Crotch.IsOrgasmSource = true;
                                    Crotch.OrgasmSourceFuckable = true;

                                    Crotch.Instance = limb.gameObject;
                                    Crotch.Dick = true;
                                    Crotch.DickModel = 2;
                                    Crotch.DickLength = 10;
                                    Crotch.DoDickAudio = true;

                                    Crotch.Balls = true;
                                    Crotch.BallsModel = 2;

                                    Crotch.CumAmt = 100; //damnnnnnnnnnnnnnnnnnnnnnn
                                    Crotch.OrgasmPeak = 150;
                                    break;
                                case "Head":
                                    var Head = limb.gameObject.AddComponent<LimbAddon>();
                                    Head.Instance = limb.gameObject;
                                    Head.Overlay = true;
                                    Head.OverlayModel = 5;
                                    Head.DmgVari_Overlay = ADVCassets.ChadDmgHairOverlay;
                                    Head.OverlaySortNum = 1;
                                    break;
                                case "UpperLegFront":
                                    var UpperLegFront = limb.gameObject.AddComponent<LimbAddon>();
                                    //UpperLegFront.transform.localScale = new Vector3(1.1f, 1.1f);
                                    UpperLegFront.Instance = limb.gameObject;
                                    UpperLegFront.Overlay = true;
                                    UpperLegFront.OverlayModel = 3;
                                    UpperLegFront.OverlaySortNum = 1;
                                    break;
                                case "UpperLeg":
                                    var UpperLeg = limb.gameObject.AddComponent<LimbAddon>();
                                    UpperLeg.Instance = limb.gameObject;
                                    UpperLeg.Overlay = true;
                                    UpperLeg.OverlayModel = 3;
                                    UpperLeg.OverlayLayer = "Background";
                                    UpperLeg.OverlaySortNum = 2;
                                    break;
                                case "UpperArmFront":
                                    var UpperArmFront = limb.gameObject.AddComponent<LimbAddon>();
                                    UpperArmFront.Instance = limb.gameObject;
                                    UpperArmFront.Overlay = true;
                                    UpperArmFront.OverlayModel = 4;
                                    UpperArmFront.OverlaySortNum = 2;
                                    break;
                                case "UpperArm":
                                    var UpperArm = limb.gameObject.AddComponent<LimbAddon>();
                                    UpperArm.Instance = limb.gameObject;
                                    UpperArm.Overlay = true;
                                    UpperArm.OverlayModel = 4;
                                    UpperArm.OverlayLayer = "Background";
                                    break;
                                default:
                                    break;
                                }
                            }
                            SetArousalNets(GetArousalNets(GenderHuman));
                            GenderHuman.SetBodyTextures(ADVCassets.ChadSkin, ADVCassets.MaleFlesh, ADVCassets.MaleBone);
                        }
                    }
            );
        //anthro fish male
            ModAPI.Register(
                new Modification()
                    {
                        OriginalItem = ModAPI.FindSpawnable("Human"),
                        NameOverride = "Male Anthro Fish",
                        NameToOrderByOverride = "!!!!!anthro_fish_male_s1",
                        DescriptionOverride = "Anthropomorphic Male Fish Character",
                        CategoryOverride = ModAPI.FindCategory("ACM"),
                        ThumbnailOverride = ModAPI.LoadSprite("assets/icons/fish_male.png"),
                        AfterSpawn = (Instance) =>
                        {
                            var GenderHuman = Instance.GetComponent<PersonBehaviour>();
							GenderHuman.SetBruiseColor(95, 49, 13);
							GenderHuman.SetSecondBruiseColor(120, 62, 20);
							GenderHuman.SetThirdBruiseColor(158, 103, 36);
							GenderHuman.SetBloodColour(247, 119, 67);
							GenderHuman.SetRottenColour(99, 76, 43);
                            foreach (var limb in GenderHuman.Limbs)
                            {
                                limb.SpeciesIdentity = "Fish";
                                switch(limb.gameObject.name) 
                                {
                                case "UpperBody":
                                    var Chest = limb.gameObject.AddComponent<LimbAddon>();
                                    Chest.Instance = limb.gameObject;
                                    Chest.Overlay = true;
                                    Chest.OverlayModel = 2;
                                    //Head.OverlaySortNum = 1;
                                    break;
                                case "LowerBody":
                                    var Crotch = limb.gameObject.AddComponent<LimbAddon>();
                                    Crotch.HasAss = true;
                                    MakeFuckable(limb.gameObject,"male");
                                    Crotch.IsOrgasmSource = true;
                                    Crotch.OrgasmSourceFuckable = true;

                                    Crotch.Instance = limb.gameObject;
                                    Crotch.Dick = true;
                                    Crotch.DickModel = 1;
                                    Crotch.DModelAdv = true;
                                    Crotch.DModelAdvSprites = ADVCassets.DickADV_Fish;
                                    Crotch.DickLength = 7; //1 less then the total dick length of the adv dick, as we're ignoring the Dick Base part of it.
                                    Crotch.DoDickAudio = true;

                                    Crotch.Tail = true;
                                    Crotch.TailModel = 2;
                                    Crotch.DmgVari_Tail = ADVCassets.TailDmg[1];

                                    Crotch.Balls = true;
                                    Crotch.BallsModel = 3;

                                    Crotch.CumColour = new Color32(252, 252, 181, 110);
                                    break;
                                case "Head":
                                    var Head = limb.gameObject.AddComponent<LimbAddon>();
                                    Head.Instance = limb.gameObject;
                                    Head.CanBlush = true;
                                    Head.BlushModel = 3;

                                    Head.Overlay = true;
                                    Head.OverlayModel = 7;
                                    Head.OverlaySortNum = 1;
                                    break;
                                default:
                                    break;
                                }
                            }
                            SetArousalNets(GetArousalNets(GenderHuman));
                            GenderHuman.SetBodyTextures(ADVCassets.FishSkinMale, ADVCassets.FishFlesh, ADVCassets.FishBone);
                        }
                    }
            );
        //anthro fish female
            ModAPI.Register(
                new Modification()
                    {
                        OriginalItem = ModAPI.FindSpawnable("Human"),
                        NameOverride = "Female Anthro Fish",
                        NameToOrderByOverride = "!!!!!anthro_fish_female_s1",
                        DescriptionOverride = "Anthropomorphic Female Fish Character",
                        CategoryOverride = ModAPI.FindCategory("ACM"),
                        ThumbnailOverride = ModAPI.LoadSprite("assets/icons/fish_female.png"),
                        AfterSpawn = (Instance) =>
                        {
                            var GenderHuman = Instance.GetComponent<PersonBehaviour>();
							GenderHuman.SetBruiseColor(95, 49, 13);
							GenderHuman.SetSecondBruiseColor(120, 62, 20);
							GenderHuman.SetThirdBruiseColor(158, 103, 36);
							GenderHuman.SetBloodColour(247, 119, 67);
							GenderHuman.SetRottenColour(99, 76, 43);
                            foreach (var limb in GenderHuman.Limbs)
                            {
                                limb.SpeciesIdentity = "Fish";
                                switch(limb.gameObject.name) 
                                {
                                case "UpperBody":
                                    var Chest = limb.gameObject.AddComponent<LimbAddon>();
                                    Chest.Instance = limb.gameObject;
                                    Chest.Overlay = true;
                                    Chest.OverlayModel = 2;
                                    
                                    Chest.Tits = true;
                                    Chest.TitsModel = 2;
                                    break;
                                case "LowerBody":
                                    var Crotch = limb.gameObject.AddComponent<LimbAddon>();
                                    Crotch.HasAss = true;
                                    Crotch.HasPussy = true;
                                    MakeFuckable(limb.gameObject,"female");
                                    Crotch.IsOrgasmSource = true;
                                    Crotch.OrgasmSourceFuckable = true;

                                    Crotch.Instance = limb.gameObject;

                                    Crotch.Tail = true;
                                    Crotch.TailModel = 2;
                                    Crotch.DmgVari_Tail = ADVCassets.TailDmg[1];

                                    Crotch.CumColour = new Color32(252, 252, 181, 110);
                                    break;
                                case "Head":
                                    var Head = limb.gameObject.AddComponent<LimbAddon>();
                                    Head.Instance = limb.gameObject;
                                    Head.CanBlush = true;
                                    Head.BlushModel = 1;
                                    Head.MoanSource = true; //experimental

                                    Head.Overlay = true;
                                    Head.OverlayModel = 8;
                                    Head.OverlaySortNum = 1;
                                    break;
                                default:
                                    break;
                                }
                            }
                            SetArousalNets(GetArousalNets(GenderHuman));
                            GenderHuman.SetBodyTextures(ADVCassets.FishSkinFemale, ADVCassets.FishFlesh, ADVCassets.FishBone);
                        }
                    }
            );
        //protogem male
            ModAPI.Register(
                new Modification()
                    {
                        OriginalItem = ModAPI.FindSpawnable("Human"),
                        NameOverride = "Male Protogen",
                        NameToOrderByOverride = "!!!!!anthro_protogen_male_s1",
                        DescriptionOverride = "Male Protogen Character with Biosynthetic male parts",
                        CategoryOverride = ModAPI.FindCategory("ACM"),
                        ThumbnailOverride = ModAPI.LoadSprite("assets/icons/proto_male.png"),
                        AfterSpawn = (Instance) =>
                        {
                            var GenderHuman = Instance.GetComponent<PersonBehaviour>();
							// GenderHuman.SetBruiseColor(79, 27, 27);
							// GenderHuman.SetSecondBruiseColor(115, 77, 69);
							// GenderHuman.SetThirdBruiseColor(165, 135, 119);
							// GenderHuman.SetBloodColour(219, 37, 37);
							GenderHuman.SetRottenColour(79, 63, 63);
                            foreach (var limb in GenderHuman.Limbs)
                            {
                                limb.RegenerationSpeed += 1f;
                                limb.ShotDamageMultiplier *= 0.8f;
								limb.ImpactPainMultiplier *= 0.6f;
                                limb.Health *= 4f;
								limb.InitialHealth *= 4f;
                                limb.BaseStrength *= 2.5f;
                                limb.SpeciesIdentity = "Protogen";
                                switch(limb.gameObject.name) 
                                {
                                case "UpperBody":
                                    var Chest = limb.gameObject.AddComponent<LimbAddon>();
                                    Chest.Instance = limb.gameObject;
                                    Chest.Overlay = true;
                                    Chest.OverlayModel = 11;
                                    Chest.DmgVari_Overlay = ADVCassets.ProtoChestDmg;
                                    SetLimbPhys(Chest.gameObject, "AndroidArmour");
                                    //Head.OverlaySortNum = 1;
                                    break;
                                case "UpperLegFront":
                                    var UpperLegFront = limb.gameObject.AddComponent<LimbAddon>();
                                    //UpperLegFront.transform.localScale = new Vector3(1.1f, 1.1f);
                                    UpperLegFront.Instance = limb.gameObject;
                                    UpperLegFront.Overlay = true;
                                    UpperLegFront.OverlayModel = 10;
                                    UpperLegFront.OverlaySortNum = 1;
                                    UpperLegFront.DmgVari_Overlay = ADVCassets.ProtoThighDmg;
                                    SetLimbPhys(UpperLegFront.gameObject, "AndroidArmour");
                                    break;
                                case "UpperLeg":
                                    var UpperLeg = limb.gameObject.AddComponent<LimbAddon>();
                                    UpperLeg.Instance = limb.gameObject;
                                    UpperLeg.Overlay = true;
                                    UpperLeg.OverlayModel = 10;
                                    UpperLeg.OverlayLayer = "Background";
                                    UpperLeg.OverlaySortNum = 2;
                                    UpperLeg.DmgVari_Overlay = ADVCassets.ProtoThighDmg;
                                    SetLimbPhys(UpperLeg.gameObject, "AndroidArmour");
                                    break;
                                case "LowerBody":
                                    var Crotch = limb.gameObject.AddComponent<LimbAddon>();
                                    Crotch.HasAss = true;
                                    MakeFuckable(limb.gameObject,"synthmale");
                                    Crotch.IsOrgasmSource = true;
                                    Crotch.OrgasmSourceFuckable = true;

                                    Crotch.Instance = limb.gameObject;
                                    Crotch.Dick = true;
                                    Crotch.DModelAdv = true;
                                    Crotch.DModelAdvSprites = ADVCassets.DickADV_Proto;
                                    Crotch.DickLength = 4; //1 less then the total dick length of the adv dick, as we're ignoring the Dick Base part of it.
                                    Crotch.DoDickAudio = true;

                                    Crotch.Tail = true;
                                    Crotch.TailModel = 3;
                                    Crotch.DmgVari_Tail = ADVCassets.TailDmg[2];

                                    Crotch.Balls = true;
                                    Crotch.BallsModel = 4;

                                    Crotch.CumColour = new Color32(163, 246, 240, 160);
                                    break;
                                case "Head":
                                    var Head = limb.gameObject.AddComponent<LimbAddon>();
                                    Head.Instance = limb.gameObject;
                                    Head.CanBlush = true;
                                    Head.BlushSortOrder = 2;
                                    Head.BlushModel = 5;
                                    Head.DmgVari_Overlay = ADVCassets.ProtoVisorDmg;

                                    Head.Overlay = true;
                                    Head.OverlayModel = 9;
                                    SetLimbPhys(Head.gameObject, "Glass");
                                    Head.OverlaySortNum = 1;
                                    Head.LargeEar = true;
                                    Head.LargeEarModel = 1;
                                    break;
                                default:
                                    break;
                                }
                            }
                            SetArousalNets(GetArousalNets(GenderHuman));
                            GenderHuman.SetBodyTextures(ADVCassets.ProtoSkinMale, ADVCassets.ProtoFlesh, ADVCassets.ProtoBone);
                        }
                    }
            );
        //protogem female
            ModAPI.Register(
                new Modification()
                    {
                        OriginalItem = ModAPI.FindSpawnable("Human"),
                        NameOverride = "Female Protogen",
                        NameToOrderByOverride = "!!!!!anthro_protogen_female_s1",
                        DescriptionOverride = "Female Protogen Character with Biosynthetic female parts",
                        CategoryOverride = ModAPI.FindCategory("ACM"),
                        ThumbnailOverride = ModAPI.LoadSprite("assets/icons/proto_female.png"),
                        AfterSpawn = (Instance) =>
                        {
                            var GenderHuman = Instance.GetComponent<PersonBehaviour>();
							GenderHuman.SetRottenColour(79, 63, 63);
                            foreach (var limb in GenderHuman.Limbs)
                            {
                                limb.RegenerationSpeed += 1f;
                                limb.ShotDamageMultiplier *= 0.8f;
								limb.ImpactPainMultiplier *= 0.6f;
                                limb.Health *= 3.8f;
								limb.InitialHealth *= 3.8f;
                                limb.BaseStrength *= 2.4f;
                                limb.SpeciesIdentity = "Protogen";
                                switch(limb.gameObject.name) 
                                {
                                case "UpperBody":
                                    var Chest = limb.gameObject.AddComponent<LimbAddon>();
                                    Chest.Instance = limb.gameObject;
                                    Chest.Overlay = true;
                                    Chest.OverlayModel = 14;
                                    Chest.DmgVari_Overlay = ADVCassets.ProtoChestDmg;
                                    SetLimbPhys(Chest.gameObject, "AndroidArmour");
                                    //Head.OverlaySortNum = 1;
                                    break;
                                case "UpperLegFront":
                                    var UpperLegFront = limb.gameObject.AddComponent<LimbAddon>();
                                    //UpperLegFront.transform.localScale = new Vector3(1.1f, 1.1f);
                                    UpperLegFront.Instance = limb.gameObject;
                                    UpperLegFront.Overlay = true;
                                    UpperLegFront.OverlayModel = 13;
                                    UpperLegFront.OverlaySortNum = 1;
                                    UpperLegFront.DmgVari_Overlay = ADVCassets.ProtoThighDmg;
                                    SetLimbPhys(UpperLegFront.gameObject, "AndroidArmour");
                                    break;
                                case "UpperLeg":
                                    var UpperLeg = limb.gameObject.AddComponent<LimbAddon>();
                                    UpperLeg.Instance = limb.gameObject;
                                    UpperLeg.Overlay = true;
                                    UpperLeg.OverlayModel = 13;
                                    UpperLeg.OverlayLayer = "Background";
                                    UpperLeg.OverlaySortNum = 2;
                                    UpperLeg.DmgVari_Overlay = ADVCassets.ProtoThighDmg;
                                    SetLimbPhys(UpperLeg.gameObject, "AndroidArmour");
                                    break;
                                case "LowerBody":
                                    var Crotch = limb.gameObject.AddComponent<LimbAddon>();
                                    Crotch.HasAss = true;
                                    Crotch.HasPussy = true;
                                    MakeFuckable(limb.gameObject,"synthfemale");
                                    Crotch.IsOrgasmSource = true;
                                    Crotch.OrgasmSourceFuckable = true;

                                    Crotch.Instance = limb.gameObject;

                                    Crotch.Tail = true;
                                    Crotch.TailModel = 3;
                                    Crotch.DmgVari_Tail = ADVCassets.TailDmg[2];

                                    Crotch.CumColour = new Color32(163, 246, 240, 160);
                                    break;
                                case "Head":
                                    var Head = limb.gameObject.AddComponent<LimbAddon>();
                                    Head.Instance = limb.gameObject;
                                    Head.CanBlush = true;
                                    Head.BlushSortOrder = 2;
                                    Head.BlushModel = 4;
                                    Head.DmgVari_Overlay = ADVCassets.ProtoVisorDmg;

                                    Head.Overlay = true;
                                    Head.OverlayModel = 12;
                                    SetLimbPhys(Head.gameObject, "Glass");
                                    Head.OverlaySortNum = 1;
                                    Head.LargeEar = true;
                                    Head.LargeEarModel = 1;
                                    break;
                                default:
                                    break;
                                }
                            }
                            SetArousalNets(GetArousalNets(GenderHuman));
                            GenderHuman.SetBodyTextures(ADVCassets.ProtoSkinFemale, ADVCassets.ProtoFlesh, ADVCassets.ProtoBone);
                        }
                    }
            );
        //anthro snake male
            ModAPI.Register(
                new Modification()
                    {
                        OriginalItem = ModAPI.FindSpawnable("Human"),
                        NameOverride = "Male Anthro Snake",
                        NameToOrderByOverride = "!!!!!anthro_snake_male_s1",
                        DescriptionOverride = "Anthropomorphic Male Snake Character",
                        CategoryOverride = ModAPI.FindCategory("ACM"),
                        ThumbnailOverride = ModAPI.LoadSprite("assets/icons/snake_male.png"),
                        AfterSpawn = (Instance) =>
                        {
                            var GenderHuman = Instance.GetComponent<PersonBehaviour>();
							GenderHuman.SetBruiseColor(61, 17, 28);
							GenderHuman.SetSecondBruiseColor(120, 20, 47);
							GenderHuman.SetThirdBruiseColor(158, 36, 85);
							GenderHuman.SetBloodColour(247, 67, 91);
							GenderHuman.SetRottenColour(82, 42, 62);
                            foreach (var limb in GenderHuman.Limbs)
                            {
                                limb.SpeciesIdentity = "Snake";
                                switch(limb.gameObject.name) 
                                {
                                case "LowerBody":
                                    var Crotch = limb.gameObject.AddComponent<LimbAddon>();
                                    MakeFuckable(limb.gameObject,"snake");
                                    Crotch.HasAss = true;
                                    Crotch.IsOrgasmSource = true;
                                    Crotch.OrgasmSourceFuckable = true;

                                    Crotch.Instance = limb.gameObject;
                                    Crotch.Dick = true;
                                    Crotch.DickModel = 1;
                                    Crotch.DModelAdv = true;
                                    Crotch.DModelAdvSprites = ADVCassets.DickADV_Snake;
                                    Crotch.DickLength = 6; //1 less then the total dick length of the adv dick, as we're ignoring the Dick Base part of it.
                                    Crotch.DoDickAudio = true;

                                    Crotch.Tail = true;
                                    Crotch.TailModel = 4;
                                    Crotch.DmgVari_Tail = ADVCassets.TailDmg[3];

                                    Crotch.Balls = true;
                                    Crotch.BallsModel = 5;

                                    Crotch.CumColour = new Color32(242, 225, 245, 100);
                                    break;
                                case "Head":
                                    var Head = limb.gameObject.AddComponent<LimbAddon>();
                                    Head.Instance = limb.gameObject;
                                    Head.CanBlush = true;
                                    Head.BlushModel = 6;

                                    Head.Overlay = true;
                                    Head.OverlayModel = 15;
                                    Head.OverlaySortNum = 1;
                                    break;
                                default:
                                    break;
                                }
                            }
                            SetArousalNets(GetArousalNets(GenderHuman));
                            GenderHuman.SetBodyTextures(ADVCassets.SnakeSkinMale, ADVCassets.SnakeFlesh, ADVCassets.SnakeBones);
                        }
                    }
            );

        //anthro snake female
            ModAPI.Register(
                new Modification()
                    {
                        OriginalItem = ModAPI.FindSpawnable("Human"),
                        NameOverride = "Female Anthro Snake",
                        NameToOrderByOverride = "!!!!!anthro_snake_female_s1",
                        DescriptionOverride = "Anthropomorphic Female Snake Character (The Developer)",
                        CategoryOverride = ModAPI.FindCategory("ACM"),
                        ThumbnailOverride = ModAPI.LoadSprite("assets/icons/snake_female.png"),
                        AfterSpawn = (Instance) =>
                        {
                            var GenderHuman = Instance.GetComponent<PersonBehaviour>();
							GenderHuman.SetBruiseColor(61, 17, 28);
							GenderHuman.SetSecondBruiseColor(120, 20, 47);
							GenderHuman.SetThirdBruiseColor(158, 36, 85);
							GenderHuman.SetBloodColour(247, 67, 91);
							GenderHuman.SetRottenColour(82, 42, 62);
                            foreach (var limb in GenderHuman.Limbs)
                            {
                                limb.SpeciesIdentity = "Snake";
                                switch(limb.gameObject.name) 
                                {
                                case "UpperBody":
                                    var Chest = limb.gameObject.AddComponent<LimbAddon>();
                                    Chest.Instance = limb.gameObject;
                                    Chest.Tits = true;
                                    Chest.TitsModel = 3;
                                    break;
                                case "LowerBody":
                                    var Crotch = limb.gameObject.AddComponent<LimbAddon>();
                                    MakeFuckable(limb.gameObject,"snake");
                                    Crotch.HasAss = true;
                                    Crotch.HasPussy = true;
                                    Crotch.IsOrgasmSource = true;
                                    Crotch.OrgasmSourceFuckable = true;

                                    Crotch.Instance = limb.gameObject;
                                    Crotch.Tail = true;
                                    Crotch.TailModel = 5;
                                    Crotch.DmgVari_Tail = ADVCassets.TailDmg[4];

                                    Crotch.CumColour = new Color32(255, 217, 253, 150);
                                    break;
                                case "Head":
                                    var Head = limb.gameObject.AddComponent<LimbAddon>();
                                    Head.Instance = limb.gameObject;
                                    Head.CanBlush = true;
                                    Head.BlushModel = 7;

                                    Head.Overlay = true;
                                    Head.OverlayModel = 16;
                                    Head.OverlaySortNum = 1;
                                    break;
                                default:
                                    break;
                                }
                            }
                            SetArousalNets(GetArousalNets(GenderHuman));
                            GenderHuman.SetBodyTextures(ADVCassets.SnakeSkinFemale, ADVCassets.SnakeFlesh, ADVCassets.SnakeBones);
                        }
                    }
            );
        //cool male human
            ModAPI.Register(
                new Modification()
                    {
                        OriginalItem = ModAPI.FindSpawnable("Human"),
                        NameOverride = "Cool Dude",
                        NameToOrderByOverride = "!!!!!humans_cool",
                        DescriptionOverride = "A Cool Guy",
                        CategoryOverride = ModAPI.FindCategory("ACM"),
                        ThumbnailOverride = ModAPI.LoadSprite("assets/icons/human_cool.png"),
                        AfterSpawn = (Instance) =>
                        {
                            var GenderHuman = Instance.GetComponent<PersonBehaviour>();
                            foreach (var limb in GenderHuman.Limbs)
                            {
                                switch(limb.gameObject.name) 
                                {
                                case "LowerBody":
                                    var Crotch = limb.gameObject.AddComponent<LimbAddon>();
                                    Crotch.HasAss = true;
                                    MakeFuckable(limb.gameObject,"male");
                                    Crotch.IsOrgasmSource = true;
                                    Crotch.OrgasmSourceFuckable = true;

                                    Crotch.Instance = limb.gameObject;
                                    Crotch.Dick = true;
                                    Crotch.DickModel = 1;
                                    Crotch.DickLength = 7;
                                    Crotch.DoDickAudio = true;

                                    Crotch.Balls = true;
                                    Crotch.BallsModel = 1;
                                    break;
                                case "Head":
                                    var Head = limb.gameObject.AddComponent<LimbAddon>();
                                    Head.Instance = limb.gameObject;
                                    Head.CanBlush = true;
                                    Head.BlushModel = 8;
                                    break;
                                default:
                                    break;
                                }
                            }
                            SetArousalNets(GetArousalNets(GenderHuman));
                            GenderHuman.SetBodyTextures(ADVCassets.CoolGuySkin, ADVCassets.MaleFlesh, ADVCassets.MaleBone);
                        }
                    }
            );
        }
        }

        public static void SetLimbPhys(GameObject PhysGO, string Mat) //shortcut method used to easily set Phys Properties of a limb 'n such.
        {
            PhysGO.GetComponent<PhysicalBehaviour>().Properties = ModAPI.FindPhysicalProperties(Mat);
        }

        public static void MakeFuckable(GameObject theObjlimb) //sets it to be fuckable
        {
            theObjlimb.name = ("Fuckable" + theObjlimb.name);
        }
        public static void MakeFuckable(GameObject theObjlimb,string sexType) //sets it to be fuckable, with a sex
        {
            theObjlimb.name = ("Fuckable_" + sexType + theObjlimb.name);
            theObjlimb.GetComponent<LimbAddon>().CustomSexInfo = sexType;
        }

        public static GameObject[] GetArousalNets(PersonBehaviour GenderHuman){
            GameObject[] NetTemp = new GameObject[] {};
            foreach (var limb in GenderHuman.Limbs)
            {
                if (!(limb.gameObject.GetComponent<LimbAddon>() == null)){
                    NetTemp = NetTemp.Concat(new[] {limb.gameObject}).ToArray();
                }
            }
            return(NetTemp);
        }

        public static void SetArousalNets(GameObject[] ArousalNet){
            for(int i = 0; i < ArousalNet.Length; i++)
            {
                LimbAddon TempGenit = ArousalNet[i].GetComponent<LimbAddon>();
                TempGenit.ArousalNetwork = ArousalNet;
                //UnityEngine.Debug.Log("SetArousalNets : " + TempGenit.ArousalNetwork[0].name);
            }
        }

        public static void RegistDildo(int DildoID, string Name, string Description, int Length = 7, bool ADVOverride = false, Sprite[] DickADV = null, int ballsID = 5){
            ModAPI.Register(
                new Modification(){
                    OriginalItem = ModAPI.FindSpawnable("Brick"),
                    NameOverride = Name,
                    NameToOrderByOverride = "!!!!!objs_dildo_" + DildoID,
                    DescriptionOverride = Description,
                    CategoryOverride = ModAPI.FindCategory("ACM"),
                    ThumbnailOverride = ADVCassets.DildoIcons[DildoID - 1],
                    AfterSpawn = (Instance) =>
                    {
                        Instance.GetComponent<SpriteRenderer>().sprite = ADVCassets.DildoMain[0]; 
                        PhysicalBehaviour PhysBehav = Instance.GetComponent<PhysicalBehaviour>();
                        PhysBehav.InitialMass = 0.25f;
                        PhysBehav.TrueInitialMass = 0.25f;
                        PhysBehav.Properties = ModAPI.FindPhysicalProperties("Rubber");

                        LimbAddon Dildo = Instance.AddComponent<LimbAddon>();
                        Dildo.Instance = Instance;
                        Dildo.Dick = true;
                        Dildo.DoDickAudio = true;
                        Dildo.IsDildo = true;
                        if (ADVOverride){//adv dick
                            Dildo.DickModel = 1;
                            Dildo.DModelAdv = true;
                            Dildo.DModelAdvSprites = DickADV;
                            Dildo.DickLength = (DickADV.Length - 1);

                            Dildo.Balls = true;
                            Dildo.BallsModel = ballsID;
                        }else{//normal non-adv dick
                            Dildo.DickModel = DildoID;
                            Dildo.DickLength = Length;
                            Dildo.Balls = true;
                            Dildo.BallsModel = DildoID;
                        }
                    }
                }
            );
        }
	}
}
